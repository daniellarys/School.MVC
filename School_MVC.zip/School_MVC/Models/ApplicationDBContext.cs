﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace School_System.Models
{
    public class ApplicationDBContext : IdentityDbContext<AppUser> {
        public DbSet<Student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Grade> Grades { get; set; }
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext>
            options):base(options){}
    }
}
