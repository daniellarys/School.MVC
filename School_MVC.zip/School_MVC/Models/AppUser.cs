﻿using Microsoft.AspNetCore.Identity;

namespace School_System.Models
{
    public class AppUser : IdentityUser
    {

    }
}
